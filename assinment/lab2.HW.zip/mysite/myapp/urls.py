from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # هذا هو المسار الأساسي للتطبيق
]
