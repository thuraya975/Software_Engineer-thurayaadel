
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'), 
     path('home/', views.home, name='home'),  # هذا هو المسار الأساسي للتطبيق
    path('editstudents/', views.editstudents, name='editstudents'),  # هذا هو المسار الأساسي للتطبيق
    path('deletestudents/', views.deletestudents, name='deletestudents'),  # هذا هو المسار الأساسي للتطبيق
    path('showstudents/', views.showstudents, name='showstudents'),  # هذا هو المسار الأساسي للتطبيق

]
