from django.shortcuts import render

#from django.http import HttpResponse


# Create your views here.

#def home(request):
   # return HttpResponse("<h2>مرحباً بك في الصفحة الرئيسية للStudents myapp!</h2>")

#def index(request):
   # return render(request,'index.html')

def home(request):
    return render(request,'home.html')
#دالة التعامل مع المتغيرات 
def showstudents(request):
    students={
        "name":"Thuraya",
        "marks":[70,76,79,65],
        "eachsub":{"Sofetware Engineering":79,
                   "Image processing":65,
                   "Client and Server Programming":76}}
    
    return render(request,'showstudents.html',students)

def deletestudents(request):
    return render(request,'deletestudents.html')
#التعامل مع for, if,else,dtl
def editstudents(request):
    students={
        "total":220,
        "marks":{"software Engineering":79,
                 "Image processing":65,
                 "Client and Server programing":76}}
    
    return render(request,'editstudents.html',students)


#التعامل مع الفلاتر التابعة dtl 
def index(request):
    name={"fname":"Thuraya"}
    return render(request,'index.html',name)
